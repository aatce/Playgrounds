import UIKit

//Optional Chaining!

struct Person{
    var age: Int
    var residence: Residence?
}

struct Residence{
    var address: Address?
}

struct Address{
    var buildingNo: String
    var streetName: String
    var apartmentNo: String?
}
